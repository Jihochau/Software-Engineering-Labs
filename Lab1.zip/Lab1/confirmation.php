<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Reservation Confirmed</title>
</head>
<body>
<h2>Your reservation has been confirmed!</h2>
<p>Thank you for your booking. We will contact you soon.</p>
</body>
</html>
