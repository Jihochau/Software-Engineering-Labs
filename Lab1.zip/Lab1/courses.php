<?php
require_once 'db.php'; // Include database connection
global $db;

// Fetch all books from database
$stmt = $db->query("SELECT title, isbn FROM book");
$books = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>CouBooks - Courses</title>
  <link rel="stylesheet" href="./css/style.css" />
</head>
<body>
<header>
  <h1>COUBOOKS</h1>
  <nav>
    <ul>
      <li><a href="./index.php">HOME</a></li>
      <li><a class="active" href="./courses.php">COURSES</a></li>
      <li><a href="./reservation.php">RESERVATION</a></li>
      <li><a href="./about.html">ABOUT</a></li>
    </ul>
  </nav>
</header>

<main>
  <h2>Below you can find an overview of all available courses:</h2>
  <ul id="book-list">
    <?php foreach ($books as $book): ?>
      <li data-isbn="<?php echo htmlspecialchars($book['isbn']); ?>">
        <?php echo htmlspecialchars($book['title']); ?>
      </li>
    <?php endforeach; ?>
  </ul>

  <!-- Placeholder for book details -->
  <div id="book-details" style="margin-top: 20px; padding: 10px; border: 1px solid #ddd;"></div>
</main>

<script>
  document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll("li[data-isbn]").forEach(book => {
      book.addEventListener("click", function() {
        let isbn = this.getAttribute("data-isbn");
        let detailsDiv = document.getElementById("book-details");

        fetch(`https://openlibrary.org/api/books?bibkeys=ISBN:${isbn}&format=json&jscmd=data`)
          .then(response => response.json())
          .then(data => {
            let bookInfo = data[`ISBN:${isbn}`];
            if (bookInfo) {
              detailsDiv.innerHTML = `
                <h3>${bookInfo.title}</h3>
                <p><strong>Author:</strong> ${bookInfo.authors ? bookInfo.authors.map(a => a.name).join(", ") : "Unknown"}</p>
                <p><strong>Published:</strong> ${bookInfo.publish_date || "Unknown"}</p>
                <p><strong>Pages:</strong> ${bookInfo.number_of_pages || "Unknown"}</p>
                <img src="${bookInfo.cover ? bookInfo.cover.medium : 'https://via.placeholder.com/150'}" alt="Book Cover">
              `;
            } else {
              detailsDiv.innerHTML = "<p>Book details not found.</p>";
            }
          })
          .catch(error => {
            console.error("Error fetching book details:", error);
            detailsDiv.innerHTML = "<p>Error retrieving book details. Please try again.</p>";
          });
      });
    });
  });
</script>

<footer>
  <p>
    Copyright © 2025
    WebTech. KU Leuven. All Rights Reserved.
    <a href="#">Privacy Policy</a> | <a href="#">Terms of Use</a>
  </p>
</footer>
</body>
</html>
