<?php
require_once 'connection.php'; // Ensure the database connection is included
global $db;

if (!$db) {
  http_response_code(500);
  echo json_encode(["error" => "Database connection failed."]);
  exit;
}

//// Debugging output
//echo json_encode(["message" => "Database connection successful."]);
//exit;

header("Content-Type: application/json"); // Set response type as JSON

// Allow both GET and POST methods
if ($_SERVER["REQUEST_METHOD"] === "POST" || $_SERVER["REQUEST_METHOD"] === "GET") {
  // Get email from request using filter_input for security
  $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL) ?: filter_input(INPUT_GET, 'email', FILTER_SANITIZE_EMAIL);

  if (empty($email)) {
    // If no email is provided, return an error
    http_response_code(400);
    echo json_encode(["error" => "Email is required."]);
    exit;
  }

  try {
    // Prepare and execute query to check if email exists in 'student' table
    $stmt = $db->prepare("SELECT email FROM student WHERE email = :email");
    $stmt->execute(['email' => $email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Debugging Output - Show the returned result
    if (!$user) {
      http_response_code(404);
      echo json_encode(["error" => "Email not found."]);
      exit;
    }

    // Check if the 'name' key exists in the result
    if (!isset($user['email'])) {
      http_response_code(500);
      echo json_encode(["error" => "Name column not found in the database result.", "debug" => $user]);
      exit;
    }

    // Email found, return welcome message
    echo json_encode(["message" => "Welcome back, " . htmlspecialchars($user['email']) . "!"]);

  } catch (Exception $e) {
    http_response_code(500);
    echo json_encode(["error" => "Server error. Please try again later.", "details" => $e->getMessage()]);
  }
} else {
  // If method is not POST or GET, return an error
  http_response_code(405);
  echo json_encode(["error" => "Invalid request method."]);
}
?>
