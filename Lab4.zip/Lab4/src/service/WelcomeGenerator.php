<?php
namespace App\Tests;

use PHPUnit\Framework\TestCase;
use App\Service\WelcomeGenerator;

class WelcomeGeneratorTest extends TestCase {
    public function testGetWelcomeReturnsExpectedValue() {
        // 1. 定义输入和预期输出
        $name = "Alice";
        $expected = "Hello, Alice!";

        // 2. 调用被测试方法
        $result = WelcomeGenerator::getWelcome($name);

        // 3. 断言返回值与预期值一致
        $this->assertSame($expected, $result);
    }
}