<?php
// src/Controller/CouBooksController.php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Feedback;
use App\Repository\FeedbackRepository;
use Doctrine\ORM\EntityManagerInterface;
//use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
//use Symfony\Component\HttpFoundation\Response;
//use Symfony\Component\Routing\Annotation\Route;

class CouBooksController extends AbstractController
{
    #[Route('/about', name: 'about')]
    public function about(): Response
    {
        return $this->render('about.html.twig');
    }

    #[Route('/', name: 'home')]
    public function home(FeedbackRepository $feedbackRepository): Response
    {
        $feedback = $feedbackRepository->findAll();
        return $this->render('home.html.twig', [
            'feedback' => $feedback,
        ]);
    }

    #[Route('/feedback', name: 'feedback')]
    public function feedback(Request $request, EntityManagerInterface $entityManager): Response
    {
        $feedback = new Feedback();
        $form = $this->createFormBuilder($feedback)
            ->add('author', TextType::class)
            ->add('text', TextareaType::class)
            ->add('save', SubmitType::class, ['label' => 'Submit Feedback'])
            ->getForm();

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $feedback->setCreated(new \DateTime());
            $entityManager->persist($feedback);
            $entityManager->flush();
            return $this->redirectToRoute('home');
        }

        return $this->render('feedback.html.twig', [
            'form' => $form->createView(),
        ]);
    }
}