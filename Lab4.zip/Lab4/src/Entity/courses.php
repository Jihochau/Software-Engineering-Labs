
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
class Course
{
#[ORM\Id]
#[ORM\GeneratedValue]
#[ORM\Column]
private ?int $id = null;

#[ORM\Column(length: 255)]
private ?string $name = null;

#[ORM\OneToMany(targetEntity: Book::class, mappedBy: 'course')]
private Collection $books;

public function __construct()
{
$this->books = new ArrayCollection();
}

// Getters and setters
public function getId(): ?int
{
return $this->id;
}

public function getName(): ?string
{
return $this->name;
}

public function setName(string $name): self
{
$this->name = $name;
return $this;
}

public function getBooks(): Collection
{
return $this->books;
}

public function addBook(Book $book): self
{
if (!$this->books->contains($book)) {
$this->books[] = $book;
$book->setCourse($this);
}
return $this;
}

public function removeBook(Book $book): self
{
if ($this->books->removeElement($book)) {
if ($book->getCourse() === $this) {
$book->setCourse(null);
}
}
return $this;
}
}