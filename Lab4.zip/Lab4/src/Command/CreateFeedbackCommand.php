<?php
// src/Command/CreateFeedbackCommand.php
namespace App\Command;

use App\Entity\Feedback;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Console\Command\Command;
use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;

class CreateFeedbackCommand extends Command
{
    protected static $defaultName = 'app:create-feedback';

    private $entityManager;

    public function __construct(EntityManagerInterface $entityManager)
    {
        $this->entityManager = $entityManager;
        parent::__construct();
    }

    protected function execute(InputInterface $input, OutputInterface $output): int
    {
        $feedback = new Feedback();
        $feedback->setAuthor('John Doe');
        $feedback->setCreated(new \DateTime());
        $feedback->setText('This is a test feedback.');

        $this->entityManager->persist($feedback);
        $this->entityManager->flush();

        $output->writeln('Feedback created and saved to the database!');
        return Command::SUCCESS;
    }
}