<?php
namespace App\Tests;

use PHPUnit\Framework\TestCase;
use App\Service\WelcomeGenerator;

class WelcomeGeneratorTest extends TestCase {
    public function testGetWelcomeReturnsExpectedValue() {
        $name = "Alice";
        $expected = "Hello, Alice!";
        $result = WelcomeGenerator::getWelcome($name);
        $this->assertSame($expected, $result);
    }

    public function testGetWelcomeWithDifferentInputs() {
        $name1 = "Bob";
        $expected1 = "Hello, Bob!";
        $this->assertSame($expected1, WelcomeGenerator::getWelcome($name1));

        $name2 = "World";
        $expected2 = "Hello, World!";
        $this->assertSame($expected2, WelcomeGenerator::getWelcome($name2));
    }
}